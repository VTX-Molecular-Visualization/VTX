#include "renderer/context/executor/opengl45.hpp"
#include "renderer/context/gl/debug.hpp"

namespace
{
	using namespace VTX;
	using namespace VTX::Renderer;

	constexpr GLenum _toGL( const uint32_t p_primitive ) noexcept
	{
		using namespace Desc;

		E_PRIMITIVE p = static_cast<E_PRIMITIVE>( p_primitive );

		switch ( p )
		{
		case E_PRIMITIVE::POINTS: return GL_POINTS;
		case E_PRIMITIVE::LINES: return GL_LINES;
		case E_PRIMITIVE::TRIANGLES: return GL_TRIANGLE_STRIP;
		case E_PRIMITIVE::PATCHES: return GL_PATCHES;
		default: assert( false ); return GL_INVALID_INDEX;
		}
	}

} // namespace

namespace VTX::Renderer::Context::Executor
{

	OpenGL45::OpenGL45( const Backend::OpenGL45 & p_backend ) : _backend( p_backend ) {}

	void OpenGL45::execute( const CommandBuffer & p_commandBuffer ) const noexcept
	{
		using namespace Desc;

		for ( const Command & command : p_commandBuffer.commands )
		{
#ifdef _DEBUG
			GL::Debug::dumpGLError();
#endif

			switch ( command.type )
			{
			case E_COMMAND::BEGIN_PASS:
			{
				const auto & p = p_commandBuffer.getPayload<PayloadBeginPass>( command.payloadOffset );

				// Bind framebuffer.
				_backend.framebuffer( p.framebuffer ).bind();

				// Setting flags.
				const uint32_t flags = p.flags;
				if ( not flags )
				{
					continue;
				}

				// Enable states.
				if ( flags & toUnderlying( E_SETTING::ENABLE_DEPTH ) )
				{
					glEnable( GL_DEPTH_TEST );
				}

				// Clear buffers.
				GLbitfield clearMask = 0;
				if ( flags & toUnderlying( E_SETTING::CLEAR_COLOR ) )
					clearMask |= GL_COLOR_BUFFER_BIT;
				if ( flags & toUnderlying( E_SETTING::CLEAR_DEPTH ) )
					clearMask |= GL_DEPTH_BUFFER_BIT;
				if ( clearMask )
					glClear( clearMask );

				break;
			}
			case E_COMMAND::END_PASS:
			{
				const auto & p = p_commandBuffer.getPayload<PayloadEndPass>( command.payloadOffset );

				// Disable states.
				if ( p.flags & toUnderlying( E_SETTING::ENABLE_DEPTH ) )
				{
					glDisable( GL_DEPTH_TEST );
				}

				break;
			}
			case E_COMMAND::BIND_RESOURCES:
			{
				const auto & p = p_commandBuffer.getPayload<PayloadBindResources>( command.payloadOffset );

				const Handle							 hResourceTable = p.resourceTable;
				const Backend::OpenGL45::ResourceTable & rt				= _backend.resourceTable( hResourceTable );

				// Textures / samplers.
				for ( const auto & textureBinding : rt.textures )
				{
					const GL::Texture2D & texture = _backend.texture( textureBinding.texture );
					const GL::Sampler &	  sampler = _backend.sampler( textureBinding.sampler );
					const Binding		  unit	  = textureBinding.unit;

					texture.bindToUnit( unit );
					sampler.bindToUnit( unit );
				}

				// Shader buffers.
				for ( const auto & bufferBinding : rt.shaderBuffers )
				{
					const GL::Buffer & buffer = _backend.shaderBuffer( bufferBinding.buffer );
					buffer.bind(
						bufferBinding.kind == E_SHADER_BUFFER_KIND::PARAMETERS ? GL_UNIFORM_BUFFER
																			   : GL_SHADER_STORAGE_BUFFER,
						bufferBinding.binding
					);
				}

				break;
			}
			case E_COMMAND::DRAW_ARRAY:
			{
				const auto & p = p_commandBuffer.getPayload<PayloadDrawArray>( command.payloadOffset );

				_backend.vertexArray( p.pipeline ).bind();
				_backend.program( p.program ).use();

				if ( p.vertexCount )
				{
					_backend.vertexArray( p.pipeline ).drawArray( _toGL( p.primitive ), 0, p.vertexCount );
				}

				break;
			}
			case E_COMMAND::DRAW_ELEMENT:
			{
				const auto & p = p_commandBuffer.getPayload<PayloadDrawElement>( command.payloadOffset );

				_backend.vertexArray( p.pipeline ).bind();
				_backend.program( p.program ).use();

				if ( p.indexCount )
				{
					_backend.vertexArray( p.pipeline )
						.drawElement( _toGL( p.primitive ), p.indexCount, GL_UNSIGNED_INT, 0 );
				}

				break;
			}
			case E_COMMAND::DRAW_ARRAYS:
			{
				const auto & p = p_commandBuffer.getPayload<PayloadDrawArrays>( command.payloadOffset );
				assert( p.vertexRanges );
				const auto * ranges = reinterpret_cast<DrawCall::RangeArrays *>( p.vertexRanges );

				_backend.vertexArray( p.pipeline ).bind();
				_backend.program( p.program ).use();

				if ( ranges && ranges->counts.size() > 0 )
				{
					assert( ranges->counts.size() == ranges->firsts.size() );

					const GLuint vaoId = _backend.vertexArray( p.pipeline ).getId();

					_backend.vertexArray( p.pipeline )
						.multiDrawArray(
							_toGL( p.primitive ),
							reinterpret_cast<const GLint *>( ranges->firsts.data() ),
							reinterpret_cast<const GLsizei *>( ranges->counts.data() ),
							static_cast<GLsizei>( ranges->counts.size() )
						);
				}

				break;
			}
			case E_COMMAND::DRAW_ELEMENTS:
			{
				const auto & p = p_commandBuffer.getPayload<PayloadDrawElements>( command.payloadOffset );
				assert( p.indexRanges );
				const auto * ranges = reinterpret_cast<DrawCall::RangeElements *>( p.indexRanges );

				_backend.vertexArray( p.pipeline ).bind();
				_backend.program( p.program ).use();

				if ( ranges && ranges->counts.size() > 0 )
				{
					assert( ranges->counts.size() == ranges->firsts.size() );
					assert( _backend.vertexArray( p.pipeline ).hasEbo() );

					_backend.vertexArray( p.pipeline )
						.multiDrawElement(
							_toGL( p.primitive ),
							reinterpret_cast<const GLsizei *>( ranges->counts.data() ),
							GL_UNSIGNED_INT,
							reinterpret_cast<const GLvoid * const *>( ranges->firsts.data() ),
							static_cast<GLsizei>( ranges->counts.size() )
						);
				}

				break;
			}
			case E_COMMAND::BIND_OUTPUT:
			{
				const auto & p = p_commandBuffer.getPayload<PayloadBindOutput>( command.payloadOffset );
				// Bind output framebuffer.
				const Handle hFramebuffer = *reinterpret_cast<Handle *>( p.framebuffer );
				_backend.framebuffer( hFramebuffer ).bind();
				break;
			}

			default: break;
			}
		}

#ifdef _DEBUG
		GL::Debug::dumpGLError();
#endif
	}

} // namespace VTX::Renderer::Context::Executor
